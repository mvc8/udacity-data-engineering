python create_tables.py
python etl.py