# DROP TABLES


from collections import OrderedDict

#Specify schema of tables
schemas = {'songplays' : OrderedDict([('songplay_id', 'varchar'), 
                                      ('start_time', 'int'), 
                                      ('user_id', 'int'),
                                      ('level', 'varchar'),
                                      ('song_id', 'varchar'),
                                      ('artist_id', 'varchar'),
                                      ('session_id', 'int'),
                                      ('location', 'varchar'),
                                      ('user_agent', 'varchar')]),
           'users' : OrderedDict([('user_id', 'int'), 
                                  ('first_name', 'varchar'), 
                                  ('last_name', 'varchar'), 
                                  ('gender', 'varchar'), 
                                  ('level', 'varchar')]),
           'songs' : OrderedDict([('song_id', 'varchar'), 
                                  ('title', 'varchar'), 
                                  ('artist_id', 'varchar'), 
                                  ('year', 'int'), 
                                  ('duration', 'int')]),
           'artists' : OrderedDict([('artist_id', 'varchar'), 
                                    ('name', 'varchar'), 
                                    ('location', 'varchar'), 
                                    ('latitude', 'int'), 
                                    ('longitude', 'int')]),
           'time' : OrderedDict([('start_time', 'timestamp'), 
                                 ('hour', 'int'), 
                                 ('day', 'int'), 
                                 ('week', 'int'), 
                                 ('month', 'int'), 
                                 ('year', 'int'), 
                                 ('weekday', 'int')]),
          }

#dictionary containing schema information; this is to be passed to SQL CREATE functions
dict_cmd = {}
for tbl, schema in schemas.items():
    cmd = ''
    for pair in schema.items():
        cmd = cmd + ' '.join(map(str, pair)) + ', '
    dict_cmd[tbl] = cmd[:-2]



#Currently not implemented -- optional dictionary that holds row data to be uploaded into tables. This can be useful for default data uploads.
dict_data = {'songplays' : [()],
        'users' : [()],
        'songs' : [()],
        'artists' : [()],
        'time' : [()]                           
            }

#To adhere to project structure, specify default SQL commands
cmd_drop = []
cmd_create = []
cmd_insert = {}
for tbl, cmd in dict_cmd.items():
    cmd_drop.append("DROP TABLE IF EXISTS %s" %tbl)
    cmd_create.append("CREATE TABLE IF NOT EXISTS %s (%s);" % (tbl, cmd))
    
    cols = ', '.join(map(str, schemas[tbl].keys()))
    cmd_insert[tbl] = "INSERT INTO {} ({}) VALUES ({})".format(tbl, cols, ','.join(['%s']*len(schemas[tbl].keys())))

# FIND SONGS
song_select = ("SELECT a.song_id, a.artist_id from songs a left join artists b on a.artist_id=b.artist_id \
                where a.title = %s and b.name = %s and a.duration = %s")

# QUERY LISTS
create_table_queries = cmd_create
drop_table_queries = cmd_drop
song_table_insert = "INSERT INTO %s (%s) VALUES %s"